package org.example;

import java.util.Scanner;

public class zadaniKlientu {
    Scanner sc = new Scanner(System.in);
    public void pridejUdajeKlienta (DatabazeKlientu klient){
        System.out.println("Zadejte jméno klienta: ");
        String jmeno = sc.nextLine();
        System.out.println("Zadejte příjmení klienta: ");
        String prijmeni = sc.nextLine();
        System.out.println("Zadejte věk klienta: ");
        int vek = Integer.parseInt(sc.nextLine());
        System.out.println("Zadejte telefonní číslo klienta: ");
        String telefon = sc.nextLine();
        klient.pridejUdajeKlienta(jmeno, prijmeni, vek, telefon);
    }
    public void vypisUdajeKlienta (DatabazeKlientu klient){
        klient.vypisUdajeKlienta();
    }
    public void vyhledejKlienta (DatabazeKlientu klient){
        System.out.println("Zadejte jméno klienta: ");
        String jmeno = sc.nextLine();
        System.out.println("Zadejte příjmení klienta: ");
        String prijmeni = sc.nextLine();
        UdajeKlienta vypis = klient.vyhledejKlienta(jmeno, prijmeni);
        if (vypis != null){
            System.out.println(vypis.toString());
        }
        else {
            System.out.println("Klient nenalezen.");
        }
    }
}
