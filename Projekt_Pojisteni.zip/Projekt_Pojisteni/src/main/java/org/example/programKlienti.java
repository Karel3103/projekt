package org.example;

import java.util.Scanner;

public class programKlienti {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DatabazeKlientu databaze = new DatabazeKlientu();
        zadaniKlientu klient = new zadaniKlientu();
        String volba = "";
        while (!volba.equals ("4")){
            System.out.println("______________________________");
            System.out.println("Evidence klientů (pojištěných)");
            System.out.println("______________________________");
            System.out.println();
            System.out.println("Vyberte akci: ");
            System.out.println("1) Přidat nového klienta");
            System.out.println("2) Vypsat všechny klienty");
            System.out.println("3) Vyhledat klienta");
            System.out.println("4) Konec");
            volba = sc.nextLine();
            System.out.println();
            switch (volba){
                case "1":
                    klient.pridejUdajeKlienta(databaze);
                    System.out.println();
                    break;
                case "2":
                    klient.vypisUdajeKlienta(databaze);
                    System.out.println();
                    break;
                case "3":
                    klient.vyhledejKlienta(databaze);
                    System.out.println();
                    break;
                case "4":
                    System.out.println("Děkuji za využití aplikace.");
                    break;
                default:
                    System.out.println("Neplatná volba, zadejte, prosím znovu.");
                    break;
            }
        }
    }
}
