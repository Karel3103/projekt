package org.example;

import java.util.ArrayList;

public class DatabazeKlientu {
    public ArrayList<UdajeKlienta> klient = new ArrayList<>();

    public void pridejUdajeKlienta(String jmeno, String prijmeni, int vek, String telefon) {
        klient.add(new UdajeKlienta(jmeno, prijmeni, vek, telefon));
        System.out.println("Klient byl úspěšně přidán.");
    }

    public void vypisUdajeKlienta() {
        for (int i = 0; i < klient.size(); i++)
            System.out.println(klient.get(i).toString());
    }


    public UdajeKlienta vyhledejKlienta (String jmeno, String prijmeni){
        UdajeKlienta vystup = null;
        for (int i = 0; i < klient.size(); i++) {
            if (klient.get(i).getJmeno().equals(jmeno) && klient.get(i).getPrijmeni().equals(prijmeni)) {
                vystup = klient.get(i);
            }
        }
        return vystup;
    }
}
